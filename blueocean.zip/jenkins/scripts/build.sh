#!/usr/bin/env sh
docker build -t toolkit -f Dockerfile .