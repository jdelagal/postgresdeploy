#!/usr/bin/env sh
docker run --name toolkit_running -u root -it -d toolkit bash
